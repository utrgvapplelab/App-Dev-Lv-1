//
//  SecondViewController.swift
//  K-12
//
//  Created by Oscar Ramos Chacon on 1/24/21.
//

import UIKit

class SecondViewController: UIViewController {

    @IBOutlet weak var mainLabel: UILabel!
    @IBOutlet weak var messageLabel: UILabel!
    @IBOutlet weak var monkeyFace: UILabel!
    
    var onLabel = "🙉"
    var offlabel = "🙈"
    
    var darkMessage = "Onta Bebe?"
    var whiteMessage = "Aqui Ta!"
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func lightsOut(_ sender: UISwitch) {
        
        if sender.isOn { view.backgroundColor = .white
            mainLabel.text = onLabel
            messageLabel.text = whiteMessage
        } else {
            view.backgroundColor = .black
            mainLabel.text = offlabel
            messageLabel.text = darkMessage
        }
    }
    @IBAction func test(_ sender: UISwitch) {
    }
    
    @IBAction func HomeButton(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }
    
}
