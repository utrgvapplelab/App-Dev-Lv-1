//
//  ViewController.swift
//  K-12
//
//  Created by Oscar Ramos Chacon on 1/24/21.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var oneLabel: UILabel!
    
    
    
    @IBOutlet weak var mainLabel: UILabel!
    @IBOutlet weak var colorMixView: UIView!
    
    @IBOutlet weak var red: UISwitch!
    @IBOutlet weak var green: UISwitch!
    @IBOutlet weak var blue: UISwitch!
    
    @IBOutlet weak var redLabel: UILabel!
    @IBOutlet weak var greenLabel: UILabel!
    @IBOutlet weak var blueLabel: UILabel!
    
    
    
    override func viewDidLoad() {
        
        
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    resetColors()
        
    }

    
    @IBAction func newButton(_ sender: UIButton) {
    }
    
    
    
    
    
    func resetColors() {
        colorMixView.backgroundColor = .clear
        red.isOn = false
        green.isOn = false
        blue.isOn = false
        redLabel.isHidden = true
        greenLabel.isHidden = true
        blueLabel.isHidden = true
        
    }
    
    @IBAction func firstColor(_ sender: UISwitch) {
        //red
        if sender.isOn {
            
            colorMixView.backgroundColor = .red
            redLabel.isHidden = false
        } else {
            colorMixView.backgroundColor = .clear
            redLabel.isHidden = true
        }
    }
    @IBAction func secondColor(_ sender: UISwitch) {
        if sender.isOn{
            colorMixView.backgroundColor = UIColor.green
            greenLabel.isHidden = false
        } else {
            colorMixView.backgroundColor = .clear
            greenLabel.isHidden = true
        }
        //green
    }
    @IBAction func thirdColor(_ sender: UISwitch) {
        //blue
        if sender.isOn {
            colorMixView.backgroundColor = UIColor.blue
            blueLabel.isHidden = false
        } else {
            colorMixView.backgroundColor = .clear
            blueLabel.isHidden = true
        }
    }
    
    @IBAction func clearButton(_ sender: UIButton) {
        
        resetColors()
        
    }
    

    
    
}



