//ADD FIRST NAME HERE:[___]
//ADD LAST NAME HERE:[___]
//ADD TODAY's DATE HERE:[___]

//_______________________________________________________

import UIKit  //This is a FRAMEWORK

//: Type Safety: Swift has type safety to prevent writing code that uses types incorrectly or unexpectedly. For example, if a function expects a type Fruit and you try to call it with a Vegetable, your app or playground won’t run until you fix the error.
//: Console pane or console area: Is a command-line environment in Xcode where you can debug or otherwise interact with an app.
//: IDE or integrated development environment: An IDE is a tightly integrated software suite that consolidates developer tools for writing and testing apps.
//: Initializer: An initializer sets up an instance so it’s ready to be used. After you declare a name for a constant or variable, you initialize the constant or variable by assigning the first value.
//: Case sensitivity: Something is case-sensitive if it matters whether characters are uppercase or lowercase.

// MARK: - IDENTIFIERS Lower Camel Case & Comments

let firstGrade = 90  // THIS IS AN IMMUTABLE (the value cannot be changed)

//let is a keyword for constants
//firstGrade is the identifier
// = is the assignment operator
// 90 is the value of the identifier(firstGrade)
// firstGrade is written the lower camel case rule

var secondGrade = 100  // THIS IS A MUTABLE (the value can be changed)

// var is a keyword for variables

secondGrade = 96

//print(firstGrade)
print(" ") // we use this function to add a space in the console.
//print(secondGrade)

// HOW TO COMMENT <<
//A readable explanation meant to help explain surrounding code Comments are not executed as part of the program. In Swift, comments are created by adding `//` in front of the comment text.

// 1. Is by using 2 forward slashes

/* 2. is by using the slash + star at the beginning and start + slash at the end. Inside are the comments.
icaiscbasbcasjbcs
jasbcjabsjcbajsc
ksabcjsabkcjbaskbcka
sbcakbskckas
*/


//MARK: - DATA TYPES, Upper Camel Case

// Type Annotation, declaring with a type

//Strings

let name = "Oscar"
var numberNine = "9.0"

var myClassToday = "Kyara and Kimberly"
print(myClassToday)

//String values must always be inside quotation marks.

let mySentence = "Hi! My name is \(name) and I'm \(numberNine) years-old."
//String Interpolation: Adding identifiers inside strings as you see above.
// Use string interpolation to put the value of a constant or a variable in the middle of a string literal. You add placeholders for constants or variables with an escape sequence that puts parentheses around the code to be replaced. For example, if friendName has been set as “Lee”, the expression “Have a good one, \(friendName)” will automatically be read as “Have a good one, Lee”.


//Integers
//Numbers with no decimals

var number = 100
//number = 99 + 1
number = 1

let integer = number


//Double and Float
//Numbers with decimals
//Double has more decimals
//Float has less

let clock = 1.2

var bankAccount = 2000.5212739

let bankAccount2 = Float(bankAccount)

var example: String = "27.3"


//Boolean (typically used on if statements, enums, and switch statements)
//Boolean values are only be true or false (2 options)
//:A Boolean type has only two possible values: true or false. Booleans are named after George Boole, a 19th century mathematician who realized how important is to ask clear questions with simple answers. In Swift, the Boolean type is called Bool.

var evidence = true
var evidence1 = false

print(" ")

print(evidence)

print(" ")


//Arrays
//Keyword used for collecting/storing data
// use square brackets to create an array

let appleLabClass = ["male", "male", "male", "female", "Oscar", "male", "male", "female", "Oscar", "male", "male", "female", "Oscar", "male", "male", "female", "Oscar", "male", "male", "female", "Oscar", "male", "male", "female", "Oscar", "male", "male", "female", "Oscar", "male", "male", "female", "Oscar", "male", "male", "female", "Oscar", "male", "male", "female", "Oscar", "male", "male", "female", "Oscar", "male", "male", "female", "Oscar", "male", "male", "female", "Oscar"]

var todaysWorkshop = [27, 18, 18, 18]

// Welcome to properties: they help you obtain insights out of objects, identifiers, and other elements.
// use properties by typing a period after the array name. Select one out of many properties.
// A property is a piece of data held by a structure, class, or enumeration. For example, each array instance has a count property that differs depending on the characteristics of the array.

appleLabClass.count
print(appleLabClass[4])

var appleLabStudents = ["Oscar", "Ana", "Carlos"]
var appleLabAges = [26,30,31]

appleLabStudents[2]
appleLabAges[0]


//Dictionary
//Keyword used for collecting/storing data with a keyword and a value.
// [Key: value]
// Type Annotation: When Swift needs more information about a certain argument or instance.

let oscar = "male"
let oscar1 : String = "Male"

var myPhoneContacts: [String:Int] = ["Oscar": 9565602575,
                           "Marco": 9001283781,
                           "Ana": 8889990001,
                           "Luis": 919283912]

//Properties
myPhoneContacts.count
myPhoneContacts.isEmpty
myPhoneContacts.values

print(myPhoneContacts.isEmpty)

print(" ")

//MARK: - FUNCTIONS ~~ // 4 types/combination of functions

    //:A function combines lines of code into a single block that can be used again. Some functions have inputs and change their behavior based on arguments from their caller, some functions have outputs and give a result, and some functions have neither.

//EXPLAIN = func functionName (parameters) -> ReturnType {
  // body of the function }


//1. No parameters & No return value
func eatNow() {
   print("Eating one tamal")
}

eatNow()

print(" ")
//--2. YES parameters & NO return value

func eatSpicyTamales(flavor:String) {
    print("My mouth is on Fire!")
}

eatSpicyTamales(flavor: "Chile")
eatSpicyTamales(flavor: "Dulce")
eatSpicyTamales(flavor: "Beans")

//3. NO parameters & YES return value

func myFunc() -> Bool {
    
    return true

}

//4. YES parameters & YES return value

func tamal(flavor: String) -> Bool {
    
    return false
}


// argument labels, default labels, parameters, data type

func sayHello(to person: String, and anotherPerson: String) {
  print("Hello \(person) and \(anotherPerson)")
}

print(" ")

sayHello(to: "Mom", and: "Dad")

sayHello(to: "Michael", and: "Alvaro")

print(" ")


//MARK: - AND MORE (Operators, If and Else Statements, Switch Statement, Loops, Structs, and Classes)

//MARK: - OPERATORS (Logical and Comparison Operators)

//Operator: An operator is a symbol – such as +, -, or && - that represents an action on one or more values. For example, in 1 + 2, the addition operator (+) adds the number 1 and 2.
//Conditional: A conditional runs multiple checks and runs code based on the results. These conditional statements are part of a broader concept called control flow. As a developer, you have control flow tools that check for certain conditions and execute different blocks of code based on those conditions.
//Logical Operator: A logical operator is a symbol – such as &&, | |, or ! – that modifies or combines the Boolean logic values true and false.

/*
 
 Comparison
 
 ==     2 items must be equal
 
 !=     The values must not be equal to each other
 
 >      Greater than
 
 <      Less than
 
 >=     Greater or equal than
 
 <=     Less or equal than
 
 
 Logical
 
 &&     AND
 
 ||     OR
 
 !      NOT
 
 */

print(" ")

//MARK: - If & else Statement
//: An if statement is a code structure for executing code based on the value of one or more conditions. The first block of code in an if statement is the if block. An if statement might also contain other blocks that provide additional checks, such as an else block and an else if block. An if-else statement is a code for executing code if a specified condition is true and for executing another block of code if its not true.

let temperature = 400

if temperature >= 100 {
  print("The water is boiling")
} else if temperature <= 100 {
  print("The water is not boiling")
} else {
print("The water is doing something else")
}

print(" ")
//MARK: - Switch Statement - For longer chains of conditions
//: The Switch operator keyword chooses between different courses of action based on a value’s characteristics. The options for the values are written in case statements. Once the switch statement finds the first match between the value and a case, the block of code next to the case statement is executed. Once one of the blocks has been executed, the program continues running the next code after the end of the entire swift statement.


let numberOfWheels = 3

switch numberOfWheels {
case 0:
    print("Missing something?")
case 1:
    print("Unicycle")
case 2:
    print("Bicycle")
case 3:
    print("Tricycle")
case 4:
    print("Quadcycle")
default:
    print("That’s a lot of wheels!")
}

print(" ")


//MARK: - Loops (For Loops, While Loops, Repeat-While Loop)

//:For loop: A for loop is a block of code that runs a certain number of times, offering a quick and easy way to do the same thing repeatedly.
//:For-in-loop: A for in loop executes on each item in a collection, looping over the collection. The block of code inside the loop will be executed once for each property.
//:While loop: A while loop is a block of code that runs for as long as a given condition remains true. When the condition changes to false, the loop stops running.
//Scenarios that require completion and repetition of a task can be done in code using loops

let index: Int
for index in 1...9 {
  print("This is number \(index)")
}

print(" ")

let names = ["Samir", "Oscar", "Vaquero"]
for name in names {
  print("Hello \(name)")
}


var lives = 3
var stillAlive = true

while stillAlive {
  lives = lives - 1
   // lives -= 1
  if lives == 0 {
    stillAlive = false
  }
}

 //Infinite Loop
//var numberOfLives = 3
//
//while numberOfLives > 0 {
//  print("I still have \(numberOfLives) lives.")
//}


//MARK: - Structs & Classes

/*
Classes are very similar to structures. Among other similarities, both can define properties to store values, define methods to provide functionality, and define initializers to set up their initial state. The syntax for doing these things is almost always identical.

You define a class using the class keyword along with a unique name. You then define properties as part of the class by listing the constant or variable declarations with the appropriate type annotation. As with structures, it’s best practice to capitalize the names of types and to use lowercase for the names of properties.
*/


struct Car {
  var make: String
  var model: String
  var year: Int
  var topSpeed: Float
}

let KymberlyCar = Car(make: "Buick", model: "Encore", year: 2019, topSpeed: 120)
let AlbertCar = Car(make: "Ford", model: "F-150", year: 2017, topSpeed: 102)


class Person {
  let name: String

  init(name: String) {
    self.name = name
  }
}

class Student: Person {
  var favoriteSubject: String


init(name: String, favoriteSubject: String) {
    self.favoriteSubject = favoriteSubject
    super.init(name: name)
  }
}


/*
Class or Structure?

Because classes and structures are so similar, it can be hard to know when to use classes and when to use structures for the building blocks of your program.
 
As a basic rule, you should start new types as structures until you need one of the features that classes provide.
Start with a class when you’re working with a framework that uses classes or when you want to refer to the same instance of a type in multiple places.
*/
