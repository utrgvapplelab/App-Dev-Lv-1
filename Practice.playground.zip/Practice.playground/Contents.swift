import UIKit //framework

//window developer documentation >> Open for more info


/* Instructions
 You have 40 to 60 minutes to open playgrounds on Xcode and try complete the following coding exercises.

1. Declare two constants: One for your first name and One for your last name using Strings. Don't forget to follow the camel case rule.
 >>>[print your constants in the console]
 
2. Declare your age into a variable using an Integer. Then use string interpolation to print the following "Hi my name is \(firstName) and I'm \(myAge) years-old"
 
3. Create an array of strings with all your family members (5 elements at minimum)
 >>>[print the array in the console]
 
 >>LOGIC SECTION<<
4. Create an if and else statement about your class / PASS or FAIL grade include (else if). Tip* Create two variables or constants for your if statement.
 
5. Create a switch and case statement about your daily routine (5 cases)
 >>LOGIC SECTION<<
 
 
6. Create a for in loop to say hi to 7 people at the same time.
 >>>[print your result in the console]
 
 
7. Create two structs, one to define your car and one to define yourself as a human.
 >>>[print one init for each]

 */












//MARK: - ANSWERS

//1.
let firstName: String = "Oscar"
let lastName: String = "Ramos"

//2.
var myAge: Int = 27
let mySentence = "Hi! My name is \(firstName) and I'm \(myAge) years-old."
print(mySentence)

print("")

//3.
let myFamily = ["Janina", "Carlos", "Efren", "Andrea", firstName + " " + lastName]
print(myFamily)
print(myFamily[3])
print(myFamily.count)
print("")



//4.
var myGrade = 89
let passingGrade = 70

if myGrade > passingGrade {
    print("Yes! I passed the Class")
} else if myGrade == passingGrade {
    print("Uff! I barely passed the Class :O")
} else {
    print("Oh No! I Failed :(")
}

// How to use my if Statement
func grade(myGrade: Int) {
    if myGrade > passingGrade {
        print("Yes! I passed the Class")
    } else if myGrade == passingGrade {
        print("Uff! I barely passed the Class :O")
    } else {
        print("Oh No! I Failed :(")
    }
}
grade(myGrade: 40)
grade(myGrade: 28)

grade(myGrade: 50)

print("")

//5.
let myDailyRoutine: Int = 1
switch myDailyRoutine {
case 1:
    print("Wake up")
case 2:
    print("Start Working")
case 3:
    print("Lunch Time")
case 4:
    print("Out of work and Ready to Swim!")
case 5:
    print("Dinner Time")
default:
    print("What time is it?")
}
// How to use my Switch Statement
func next(myDailyRoutine: Int) {
    switch myDailyRoutine {
    case 1:
        print("Wake up")
    case 2:
        print("Start Working")
    case 3:
        print("Lunch Time")
    case 4:
        print("Out of work and Ready to Swim!")
    case 5:
        print("Dinner Time")
    default:
        print("What time is it?")
    }
}
next(myDailyRoutine: 10)
next(myDailyRoutine: 100)

print("")

//6.
let greeting = "Hello"
let people = ["Oscar", "Paco", "Santiago", "Julio", "Carlos", "Roberto", "Ana"]
for human in people {
    print("\(greeting + " " + human)")
    
}

print("")


//7. 
struct MyCar {
    let make: String
    let year: Int
    let model: String
    let maxSpeed: Int
    var mySpeed: Int
}

//initializing
let car1 = MyCar(make: "Ford", year: 2017, model: "Focus", maxSpeed: 170, mySpeed: 55)
 
print(car1)

struct Human {
    let DOB: String
    var weight: Int
    let height: Float
    let sex: String
    var age: Int
    var alive: Bool
}

let Oscar = Human(DOB: "11/30/1993", weight: 200, height: 5.9, sex: "Male", age: 26, alive: true)

print(Oscar)








