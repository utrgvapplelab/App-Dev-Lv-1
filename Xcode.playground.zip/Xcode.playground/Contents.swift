import UIKit


//MARK: - Xcode

/*

 1. Xcode Map Handout
 2. Xcode Shortcuts Shortcuts
 3. Project Navigator
 4. Source Control
 5. Issue Navigator
 6. Debugg & Breakpoint Navigator
 7. Main Storyboard and View Controller
 8. Assets and Launch Screen
 9. Console or Debug Pane (shift + command + C)
 10. Document outline
 11. Interface Builder
 12. Inspector Pane
 13. Status Bar
 14. Project Settings
 15. Simulator
 

//MARK:- Xcode Practice

// Develop the 101 App
 
 //MARK:- Clonning
 
Cloning Demonstration
Clone Project Link: https://github.com/fullstackio/FlappySwift

*/

